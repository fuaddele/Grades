// Get all the input elements with class "grade-input"
const gradeInputs = document.querySelectorAll('.grade');

// Get all the average output elements
const averageOutputs = document.querySelectorAll('.average');

// Get the element that displays the missing cell count
const missingCount = document.getElementById('un-submitted');

// Get the average column header element
const averageHeader = document.getElementById('average-header');

// Calculate the average whenever a grade input is changed
function calculateAverage() {
  // Loop through each row
  let missingCellCount = 0;
  for (let i = 0; i < averageOutputs.length; i++) {
    // Get the values of all the grade inputs for this row
    const grades = Array.from(gradeInputs).slice(i * 5, i * 5 + 5).map(input => {
      const grade = parseFloat(input.value);
      if (isNaN(grade) || grade < 0 || grade > 100) {
        // Replace the input with a hyphen if it's not a valid number between 0-100
        input.value = '-';
        return 0;
      } else {
        return grade;
      }
    });

    // Calculate the average
    const average = grades.reduce((sum, grade) => sum + grade, 0) / grades.length;
    // Rounds the average to the nearest number
    rounded = Math.round(average);

    // Update the corresponding average output element with the result
    const output = averageOutputs[i];
    output.textContent = isNaN(average) ? '' : rounded;

    // Change the background color if the average is below 60
    if (average < 60) {
      output.parentNode.classList.add('below-60');
    } else {
      output.parentNode.classList.remove('below-60');
    }

    // Count the number of missing cells in this row
    const rowMissingCellCount = grades.filter(grade => grade === 0).length;
    missingCellCount += rowMissingCellCount;
  }

  // Display the missing cell count
  missingCount.textContent = `A total of ${missingCellCount} are yet to be submitted`;
}

// Attach event listeners to each grade input

gradeInputs.forEach(input => {
  input.addEventListener('input', calculateAverage);

  // Set the background color to yellow if the input is empty
  if (!isNaN(this.innerText) && this.innerText) {
    input.classList.remove('yellow');
  }else {
    input.classList.add('yellow');
  }
});

// Calculate the averages initially
calculateAverage();

function getLetterGrade(average) {
  if (average >= 93) {
    return 'A';
  } else if (average <= 92 && average >= 90) {
    return 'A-';
  } else if (average <= 89 && average >= 87) {
    return 'B+';
  } else if (average <= 86 && average >= 83) {
    return 'B';
  } else if (average <= 82 && average >= 80) {
    return 'B-';
  } else if (average <= 79 && average >= 77) {
    return 'C+';
  } else if (average <= 76 && average >= 73) {
    return 'C';
  } else if (average <= 72 && average >= 70) {
    return 'C-';
  } else if (average <= 69 && average >= 67) {
    return 'D+';
  } else if (average <= 66 && average >= 63) {
    return 'D';
  } else if (average <= 62 && average >= 60) {
    return 'D-';
  } else {
    return 'F';
  }
}


// Define a function that calculates the 4.0 scale equivalent of a given average
function get4PointScale(average) {
  if (average >= 93) {
    return 4.0;
  } else if (average <= 92 && average >= 90) {
    return 3.7;
  } else if (average <= 89 && average >= 87) {
    return 3.3;
  } else if (average <= 86 && average >= 83) {
    return 3.0;
  } else if (average <= 82 && average >= 80) {
    return 2.7;
  } else if (average <= 79 && average >= 77) {
    return 2.3;
  } else if (average <= 76 && average >= 73) {
    return 2.0;
  } else if (average <= 72 && average >= 70) {
    return 1.7;
  } else if (average <= 69 && average >= 67) {
    return 1.3;
  } else if (average <= 66 && average >= 63) {
    return 1.0;
  } else if (average <= 62 && average >= 60) {
    return 0.7;
  } else {
    return 0.0;
  }
}

// Define a function that toggles the view of the average column
let view = 0; // 0 = average view, 1 = letter grade view, 2 = 4.0 scale view
function toggleAverageView() {
  // Toggle the view
  view = (view + 1) % 3;

  if (view === 1) {    
    // 4.0 scale view
    averageHeader.textContent = '4.0 Scale';
    averageOutputs.forEach(output => {
      const average = parseFloat(output.textContent);
      const scale = get4PointScale(average);
      output.textContent = scale.toFixed(1);
    });
  } else if (view === 2) {
    // Letter grade view
    averageHeader.textContent = 'Letter Grade';
    if (averageOutputs.length > 0) {
      averageOutputs.forEach(output => {
        const average = parseFloat(output.textContent);
        const letterGrade = getLetterGrade(average);
        output.textContent = letterGrade;
      });
    }
  } else {
    // Average view
    averageHeader.textContent = 'Average Grade';
    calculateAverage(); // Calculate the averages again
  }
}


// Attach event listener to the average header element
averageHeader.addEventListener('click', toggleAverageView);


const addRowButton = document.getElementById('add-row-btn');
const tableBody = document.querySelector('tbody');

addRowButton.addEventListener('click', function() {
  const newRow = document.createElement('tr');
  newRow.innerHTML = `
  <td><input type="text" placeholder="-"></td>
  <td><input type="number" placeholder="-"></td>
  <td><input type="number" class="grade" placeholder="-"></td>
  <td><input type="number" class="grade" placeholder="-"></td>
  <td><input type="number" class="grade" placeholder="-"></td>
  <td><input type="number" class="grade" placeholder="-"></td>
  <td><input type="number" class="grade" placeholder="-"></td>
  <td><span class="average"></span></td>
  `;
  tableBody.appendChild(newRow);

  
});


const addColumnButton = document.getElementById('add-column-btn');
const tableBod = document.querySelector('tr');

addColumnButton.addEventListener('click', function() {
  const newColumn = document.createElement('tbody');
  newColumn.innerHTML = `
  <tr>
      <th>Assignment</th>
  </tr>
  <tr>
  <td><input type="number" class="grade" placeholder="-"></td>
  </tr>
  <tr>
  <td><input type="number" class="grade" placeholder="-"></td>
  </tr>
  <tr>
  <td><input type="number" class="grade" placeholder="-"></td>
  </tr>
  <tr>
  <td><input type="number" class="grade" placeholder="-"></td>
  </tr>
  `;
  tableBody.appendChild(newColumn);

  
});

